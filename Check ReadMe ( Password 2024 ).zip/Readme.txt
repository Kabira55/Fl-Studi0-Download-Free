**Password**: `2024`
**Extract the files**:
   - Locate the downloaded file on your computer.
   - Right-click on the file and select "Extract All" or use any extraction tool (like WinRAR or 7-Zip).
**Run the application**:
   - Open the extracted folder.
   - Find the executable file (e.g., `Installer_Phoenix.exe`) and double-click it to run.
**Follow the on-screen instructions**:
   - Adjust any settings as needed to suit your preferences.
**Check for updates**:
   - Stay tuned for updates to get new features or fixes.